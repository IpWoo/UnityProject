#if UNITY_2017_1_OR_NEWER
namespace UnityGLTF
{
    public enum GLTFImporterNormals
    {
        Import,
        Calculate,
        None
    }
}
#endif
